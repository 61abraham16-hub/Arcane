# Security Policy

- Report vulnerabilities via private email: security@example.com
- Please do **not** open public issues for security problems
- We aim to respond within 72 hours

## Supported versions
We follow the latest release + previous minor.
