# Code of Conduct

This project follows the Contributor Covenant. By participating, you are expected to uphold this code.

- Be respectful, inclusive, and considerate.
- Assume good intent; disagree constructively.
- No harassment, discrimination, or personal attacks.

For issues, contact the maintainers at SECURITY.md contacts.
