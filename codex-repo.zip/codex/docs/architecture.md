# Architecture Notes

Use this space to document high-level system design, modules, and decisions.
Keep it updated as the project evolves.

- Goals
- Non-goals
- Key components
- Data flow
- Open questions
