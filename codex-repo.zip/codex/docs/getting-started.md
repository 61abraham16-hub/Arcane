# Getting Started

Welcome to Codex!

1. Clone the repo
2. Choose your language stack (Node/Python/.NET/etc.)
3. Put your code in `src/` and tests in `tests/`
4. Run CI locally (optional) then push

If you're using GitHub, issues and PR templates are ready for you.
