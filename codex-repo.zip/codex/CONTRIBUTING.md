# Contributing to Codex

Thanks for your interest!

## Development flow
1. Fork & create a feature branch
2. Make changes with clear, small commits
3. Add/adjust tests
4. Update docs if needed
5. Open a Pull Request (PR) following the template

## Commit style
Use conventional commits:
- `feat:`, `fix:`, `docs:`, `refactor:`, `perf:`, `test:`, `chore:`

## Code style
- Respect `.editorconfig`
- Add docstrings/comments for complex parts
- Keep functions small and focused
