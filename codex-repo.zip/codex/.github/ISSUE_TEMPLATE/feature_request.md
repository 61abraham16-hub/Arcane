---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
assignees: ''
---

**Problem**
What's missing or could be improved?

**Proposed solution**
What would you like to see?

**Alternatives**
Any alternative solutions you've considered.

**Additional context**
Add any other context here.
